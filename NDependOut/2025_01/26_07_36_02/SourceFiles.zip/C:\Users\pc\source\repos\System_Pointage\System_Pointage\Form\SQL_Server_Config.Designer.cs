﻿namespace System_Pointage.Form
{
    partial class SQL_Server_Config
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button3 = new DevExpress.XtraEditors.SimpleButton();
            this.GroupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.ComboBoxEdit3 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.Button2 = new DevExpress.XtraEditors.SimpleButton();
            this.Button1 = new DevExpress.XtraEditors.SimpleButton();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.TextEdit2 = new DevExpress.XtraEditors.TextEdit();
            this.TextEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.ComboBoxEdit2 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.ComboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.LabelControl6 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).BeginInit();
            this.GroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ComboBoxEdit3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ComboBoxEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ComboBoxEdit1.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // Button3
            // 
            this.Button3.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button3.Appearance.Options.UseFont = true;
            this.Button3.Appearance.Options.UseTextOptions = true;
            this.Button3.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.Button3.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.Button3.Location = new System.Drawing.Point(63, 579);
            this.Button3.Margin = new System.Windows.Forms.Padding(4);
            this.Button3.Name = "Button3";
            this.Button3.Size = new System.Drawing.Size(118, 60);
            this.Button3.TabIndex = 41;
            this.Button3.Text = "SAVE";
            this.Button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // GroupControl1
            // 
            this.GroupControl1.Controls.Add(this.ComboBoxEdit3);
            this.GroupControl1.Controls.Add(this.Button2);
            this.GroupControl1.Controls.Add(this.Button1);
            this.GroupControl1.Controls.Add(this.LabelControl5);
            this.GroupControl1.Controls.Add(this.LabelControl4);
            this.GroupControl1.Controls.Add(this.TextEdit2);
            this.GroupControl1.Controls.Add(this.TextEdit1);
            this.GroupControl1.Controls.Add(this.LabelControl3);
            this.GroupControl1.Controls.Add(this.LabelControl2);
            this.GroupControl1.Controls.Add(this.LabelControl1);
            this.GroupControl1.Controls.Add(this.ComboBoxEdit2);
            this.GroupControl1.Controls.Add(this.ComboBoxEdit1);
            this.GroupControl1.Location = new System.Drawing.Point(56, 125);
            this.GroupControl1.Margin = new System.Windows.Forms.Padding(4);
            this.GroupControl1.Name = "GroupControl1";
            this.GroupControl1.Size = new System.Drawing.Size(915, 398);
            this.GroupControl1.TabIndex = 43;
            // 
            // ComboBoxEdit3
            // 
            this.ComboBoxEdit3.Location = new System.Drawing.Point(390, 136);
            this.ComboBoxEdit3.Margin = new System.Windows.Forms.Padding(4);
            this.ComboBoxEdit3.Name = "ComboBoxEdit3";
            this.ComboBoxEdit3.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxEdit3.Properties.Appearance.Options.UseFont = true;
            this.ComboBoxEdit3.Properties.Appearance.Options.UseTextOptions = true;
            this.ComboBoxEdit3.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ComboBoxEdit3.Properties.AppearanceDropDown.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxEdit3.Properties.AppearanceDropDown.Options.UseFont = true;
            this.ComboBoxEdit3.Properties.AppearanceDropDown.Options.UseTextOptions = true;
            this.ComboBoxEdit3.Properties.AppearanceDropDown.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ComboBoxEdit3.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ComboBoxEdit3.Size = new System.Drawing.Size(492, 32);
            this.ComboBoxEdit3.TabIndex = 13;
            // 
            // Button2
            // 
            this.Button2.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button2.Appearance.Options.UseFont = true;
            this.Button2.Appearance.Options.UseTextOptions = true;
            this.Button2.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.Button2.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleRight;
            this.Button2.Location = new System.Drawing.Point(8, 294);
            this.Button2.Margin = new System.Windows.Forms.Padding(4);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(874, 85);
            this.Button2.TabIndex = 12;
            this.Button2.Text = "[ TESTER CONNECTION ]";
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // Button1
            // 
            this.Button1.Appearance.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button1.Appearance.Options.UseFont = true;
            this.Button1.Appearance.Options.UseTextOptions = true;
            this.Button1.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.Button1.Appearance.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            this.Button1.ImageOptions.Location = DevExpress.XtraEditors.ImageLocation.MiddleCenter;
            this.Button1.Location = new System.Drawing.Point(748, 42);
            this.Button1.Margin = new System.Windows.Forms.Padding(4);
            this.Button1.Name = "Button1";
            this.Button1.Size = new System.Drawing.Size(134, 38);
            this.Button1.TabIndex = 11;
            this.Button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl5.Appearance.ForeColor = System.Drawing.Color.Goldenrod;
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Appearance.Options.UseForeColor = true;
            this.LabelControl5.Appearance.Options.UseTextOptions = true;
            this.LabelControl5.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.LabelControl5.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.LabelControl5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.LabelControl5.Location = new System.Drawing.Point(8, 229);
            this.LabelControl5.Margin = new System.Windows.Forms.Padding(4);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(374, 38);
            this.LabelControl5.TabIndex = 10;
            this.LabelControl5.Text = "MOT DE PASSE :";
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl4.Appearance.ForeColor = System.Drawing.Color.Goldenrod;
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Appearance.Options.UseForeColor = true;
            this.LabelControl4.Appearance.Options.UseTextOptions = true;
            this.LabelControl4.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.LabelControl4.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.LabelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.LabelControl4.Location = new System.Drawing.Point(8, 183);
            this.LabelControl4.Margin = new System.Windows.Forms.Padding(4);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(374, 38);
            this.LabelControl4.TabIndex = 9;
            this.LabelControl4.Text = "NOM UTILISATEUR :";
            // 
            // TextEdit2
            // 
            this.TextEdit2.Location = new System.Drawing.Point(390, 229);
            this.TextEdit2.Margin = new System.Windows.Forms.Padding(4);
            this.TextEdit2.Name = "TextEdit2";
            this.TextEdit2.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextEdit2.Properties.Appearance.Options.UseFont = true;
            this.TextEdit2.Properties.Appearance.Options.UseTextOptions = true;
            this.TextEdit2.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.TextEdit2.Size = new System.Drawing.Size(492, 32);
            this.TextEdit2.TabIndex = 8;
            // 
            // TextEdit1
            // 
            this.TextEdit1.Location = new System.Drawing.Point(390, 183);
            this.TextEdit1.Margin = new System.Windows.Forms.Padding(4);
            this.TextEdit1.Name = "TextEdit1";
            this.TextEdit1.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextEdit1.Properties.Appearance.Options.UseFont = true;
            this.TextEdit1.Properties.Appearance.Options.UseTextOptions = true;
            this.TextEdit1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.TextEdit1.Size = new System.Drawing.Size(492, 32);
            this.TextEdit1.TabIndex = 7;
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl3.Appearance.ForeColor = System.Drawing.Color.Goldenrod;
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Appearance.Options.UseForeColor = true;
            this.LabelControl3.Appearance.Options.UseTextOptions = true;
            this.LabelControl3.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.LabelControl3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.LabelControl3.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.LabelControl3.Location = new System.Drawing.Point(8, 136);
            this.LabelControl3.Margin = new System.Windows.Forms.Padding(4);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(374, 38);
            this.LabelControl3.TabIndex = 6;
            this.LabelControl3.Text = "BASE DE DONNEES :";
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl2.Appearance.ForeColor = System.Drawing.Color.Goldenrod;
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Appearance.Options.UseForeColor = true;
            this.LabelControl2.Appearance.Options.UseTextOptions = true;
            this.LabelControl2.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.LabelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.LabelControl2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.LabelControl2.Location = new System.Drawing.Point(8, 89);
            this.LabelControl2.Margin = new System.Windows.Forms.Padding(4);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(372, 38);
            this.LabelControl2.TabIndex = 3;
            this.LabelControl2.Text = "MODE AUTHENTIFICATION :";
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl1.Appearance.ForeColor = System.Drawing.Color.Goldenrod;
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Appearance.Options.UseForeColor = true;
            this.LabelControl1.Appearance.Options.UseTextOptions = true;
            this.LabelControl1.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.LabelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.LabelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.LabelControl1.Location = new System.Drawing.Point(8, 42);
            this.LabelControl1.Margin = new System.Windows.Forms.Padding(4);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(374, 38);
            this.LabelControl1.TabIndex = 2;
            this.LabelControl1.Text = "SERVER NAME :";
            // 
            // ComboBoxEdit2
            // 
            this.ComboBoxEdit2.Location = new System.Drawing.Point(390, 89);
            this.ComboBoxEdit2.Margin = new System.Windows.Forms.Padding(4);
            this.ComboBoxEdit2.Name = "ComboBoxEdit2";
            this.ComboBoxEdit2.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxEdit2.Properties.Appearance.Options.UseFont = true;
            this.ComboBoxEdit2.Properties.Appearance.Options.UseTextOptions = true;
            this.ComboBoxEdit2.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ComboBoxEdit2.Properties.AppearanceDropDown.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxEdit2.Properties.AppearanceDropDown.Options.UseFont = true;
            this.ComboBoxEdit2.Properties.AppearanceDropDown.Options.UseTextOptions = true;
            this.ComboBoxEdit2.Properties.AppearanceDropDown.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ComboBoxEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ComboBoxEdit2.Size = new System.Drawing.Size(492, 32);
            this.ComboBoxEdit2.TabIndex = 1;
            this.ComboBoxEdit2.SelectedIndexChanged += new System.EventHandler(this.ComboBoxEdit2_SelectedIndexChanged);
            // 
            // ComboBoxEdit1
            // 
            this.ComboBoxEdit1.Location = new System.Drawing.Point(390, 42);
            this.ComboBoxEdit1.Margin = new System.Windows.Forms.Padding(4);
            this.ComboBoxEdit1.Name = "ComboBoxEdit1";
            this.ComboBoxEdit1.Properties.Appearance.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxEdit1.Properties.Appearance.Options.UseFont = true;
            this.ComboBoxEdit1.Properties.Appearance.Options.UseTextOptions = true;
            this.ComboBoxEdit1.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ComboBoxEdit1.Properties.AppearanceDropDown.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComboBoxEdit1.Properties.AppearanceDropDown.Options.UseFont = true;
            this.ComboBoxEdit1.Properties.AppearanceDropDown.Options.UseTextOptions = true;
            this.ComboBoxEdit1.Properties.AppearanceDropDown.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.ComboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ComboBoxEdit1.Size = new System.Drawing.Size(350, 32);
            this.ComboBoxEdit1.TabIndex = 0;
            this.ComboBoxEdit1.SelectedIndexChanged += new System.EventHandler(this.ComboBoxEdit1_SelectedIndexChanged);
            // 
            // LabelControl6
            // 
            this.LabelControl6.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl6.Appearance.ForeColor = System.Drawing.Color.Orange;
            this.LabelControl6.Appearance.Options.UseFont = true;
            this.LabelControl6.Appearance.Options.UseForeColor = true;
            this.LabelControl6.Appearance.Options.UseTextOptions = true;
            this.LabelControl6.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            this.LabelControl6.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.LabelControl6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Simple;
            this.LabelControl6.Location = new System.Drawing.Point(106, 13);
            this.LabelControl6.Margin = new System.Windows.Forms.Padding(4);
            this.LabelControl6.Name = "LabelControl6";
            this.LabelControl6.Size = new System.Drawing.Size(807, 86);
            this.LabelControl6.TabIndex = 42;
            this.LabelControl6.Text = "SQL SERVER CONFIGURATION ";
            // 
            // SQL_Server_Config
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1028, 655);
            this.Controls.Add(this.Button3);
            this.Controls.Add(this.GroupControl1);
            this.Controls.Add(this.LabelControl6);
            this.Name = "SQL_Server_Config";
            this.Text = "SQL_Server_Config";
            this.Load += new System.EventHandler(this.SQL_Server_Config_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).EndInit();
            this.GroupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ComboBoxEdit3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ComboBoxEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ComboBoxEdit1.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal DevExpress.XtraEditors.SimpleButton Button3;
        internal DevExpress.XtraEditors.GroupControl GroupControl1;
        internal DevExpress.XtraEditors.ComboBoxEdit ComboBoxEdit3;
        internal DevExpress.XtraEditors.SimpleButton Button2;
        internal DevExpress.XtraEditors.SimpleButton Button1;
        internal DevExpress.XtraEditors.LabelControl LabelControl5;
        internal DevExpress.XtraEditors.LabelControl LabelControl4;
        internal DevExpress.XtraEditors.TextEdit TextEdit2;
        internal DevExpress.XtraEditors.TextEdit TextEdit1;
        internal DevExpress.XtraEditors.LabelControl LabelControl3;
        internal DevExpress.XtraEditors.LabelControl LabelControl2;
        internal DevExpress.XtraEditors.LabelControl LabelControl1;
        internal DevExpress.XtraEditors.ComboBoxEdit ComboBoxEdit2;
        internal DevExpress.XtraEditors.ComboBoxEdit ComboBoxEdit1;
        internal DevExpress.XtraEditors.LabelControl LabelControl6;
    }
}