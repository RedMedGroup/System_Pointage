﻿namespace System_Pointage.report
{
    partial class rpt_pointage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rpt_pointage));
            this.TopMargin = new DevExpress.XtraReports.UI.TopMarginBand();
            this.BottomMargin = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.xrTableDetail = new DevExpress.XtraReports.UI.XRTable();
            this.xrTableRow2 = new DevExpress.XtraReports.UI.XRTableRow();
            this.cell_sp = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_required = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_name = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_6 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_7 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_8 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_9 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_10 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_11 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_12 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_13 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_14 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_15 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_16 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_17 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_18 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_19 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_20 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_21 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_22 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_23 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_24 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_25 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_26 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_27 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_28 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_29 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_30 = new DevExpress.XtraReports.UI.XRTableCell();
            this.cell_31 = new DevExpress.XtraReports.UI.XRTableCell();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.xrRichText1 = new DevExpress.XtraReports.UI.XRRichText();
            this.xrPictureBox1 = new DevExpress.XtraReports.UI.XRPictureBox();
            this.lbl_date = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel7 = new DevExpress.XtraReports.UI.XRLabel();
            this.xrLabel2 = new DevExpress.XtraReports.UI.XRLabel();
            this.GroupHeader1 = new DevExpress.XtraReports.UI.GroupHeaderBand();
            this.xrTableHeader = new DevExpress.XtraReports.UI.XRTable();
            this.tableRow1 = new DevExpress.XtraReports.UI.XRTableRow();
            this.xrTableCell1 = new DevExpress.XtraReports.UI.XRTableCell();
            this.Bloc = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell3 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell2 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell4 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell5 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell6 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell7 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell8 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell9 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell10 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell11 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell12 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell13 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell14 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell15 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell16 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell17 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell18 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell19 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell20 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell21 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell22 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell23 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell24 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell25 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell26 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell27 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell28 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell29 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell30 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell31 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell32 = new DevExpress.XtraReports.UI.XRTableCell();
            this.xrTableCell33 = new DevExpress.XtraReports.UI.XRTableCell();
            this.GroupFooter1 = new DevExpress.XtraReports.UI.GroupFooterBand();
            this.xrLabel1 = new DevExpress.XtraReports.UI.XRLabel();
            ((System.ComponentModel.ISupportInitialize)(this.xrTableDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrRichText1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTableHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // TopMargin
            // 
            this.TopMargin.HeightF = 12.5F;
            this.TopMargin.Name = "TopMargin";
            // 
            // BottomMargin
            // 
            this.BottomMargin.Name = "BottomMargin";
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTableDetail});
            this.Detail.HeightF = 25F;
            this.Detail.Name = "Detail";
            // 
            // xrTableDetail
            // 
            this.xrTableDetail.BackColor = System.Drawing.Color.Transparent;
            this.xrTableDetail.BorderDashStyle = DevExpress.XtraPrinting.BorderDashStyle.Double;
            this.xrTableDetail.Borders = ((DevExpress.XtraPrinting.BorderSide)((((DevExpress.XtraPrinting.BorderSide.Left | DevExpress.XtraPrinting.BorderSide.Top) 
            | DevExpress.XtraPrinting.BorderSide.Right) 
            | DevExpress.XtraPrinting.BorderSide.Bottom)));
            this.xrTableDetail.LocationFloat = new DevExpress.Utils.PointFloat(1.000108F, 0F);
            this.xrTableDetail.Name = "xrTableDetail";
            this.xrTableDetail.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 96F);
            this.xrTableDetail.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.xrTableRow2});
            this.xrTableDetail.SizeF = new System.Drawing.SizeF(1159F, 25F);
            this.xrTableDetail.StylePriority.UseBackColor = false;
            this.xrTableDetail.StylePriority.UseBorderDashStyle = false;
            this.xrTableDetail.StylePriority.UseBorders = false;
            // 
            // xrTableRow2
            // 
            this.xrTableRow2.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.cell_sp,
            this.cell_required,
            this.cell_name,
            this.cell_1,
            this.cell_2,
            this.cell_3,
            this.cell_4,
            this.cell_5,
            this.cell_6,
            this.cell_7,
            this.cell_8,
            this.cell_9,
            this.cell_10,
            this.cell_11,
            this.cell_12,
            this.cell_13,
            this.cell_14,
            this.cell_15,
            this.cell_16,
            this.cell_17,
            this.cell_18,
            this.cell_19,
            this.cell_20,
            this.cell_21,
            this.cell_22,
            this.cell_23,
            this.cell_24,
            this.cell_25,
            this.cell_26,
            this.cell_27,
            this.cell_28,
            this.cell_29,
            this.cell_30,
            this.cell_31});
            this.xrTableRow2.Name = "xrTableRow2";
            this.xrTableRow2.Weight = 1D;
            // 
            // cell_sp
            // 
            this.cell_sp.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[Specialization]")});
            this.cell_sp.Multiline = true;
            this.cell_sp.Name = "cell_sp";
            this.cell_sp.StylePriority.UseTextAlignment = false;
            this.cell_sp.Text = "cell_sp";
            this.cell_sp.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_sp.Weight = 1.3308891947883499D;
            // 
            // cell_required
            // 
            this.cell_required.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[RequiredQuantity]")});
            this.cell_required.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_required.ForeColor = System.Drawing.Color.Black;
            this.cell_required.Multiline = true;
            this.cell_required.Name = "cell_required";
            this.cell_required.StylePriority.UseFont = false;
            this.cell_required.StylePriority.UseForeColor = false;
            this.cell_required.StylePriority.UseTextAlignment = false;
            this.cell_required.Text = "cell_required";
            this.cell_required.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            this.cell_required.Weight = 0.5888824107682652D;
            // 
            // cell_name
            // 
            this.cell_name.ExpressionBindings.AddRange(new DevExpress.XtraReports.UI.ExpressionBinding[] {
            new DevExpress.XtraReports.UI.ExpressionBinding("BeforePrint", "Text", "[Name]")});
            this.cell_name.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_name.ForeColor = System.Drawing.Color.Black;
            this.cell_name.Multiline = true;
            this.cell_name.Name = "cell_name";
            this.cell_name.StylePriority.UseFont = false;
            this.cell_name.StylePriority.UseForeColor = false;
            this.cell_name.StylePriority.UseTextAlignment = false;
            this.cell_name.Text = "cell_name";
            this.cell_name.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_name.Weight = 1.3867319504569737D;
            // 
            // cell_1
            // 
            this.cell_1.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_1.ForeColor = System.Drawing.Color.Black;
            this.cell_1.Multiline = true;
            this.cell_1.Name = "cell_1";
            this.cell_1.StylePriority.UseFont = false;
            this.cell_1.StylePriority.UseForeColor = false;
            this.cell_1.StylePriority.UseTextAlignment = false;
            this.cell_1.Text = "cell_1";
            this.cell_1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_1.Weight = 0.34849333018761119D;
            // 
            // cell_2
            // 
            this.cell_2.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_2.ForeColor = System.Drawing.Color.Black;
            this.cell_2.Multiline = true;
            this.cell_2.Name = "cell_2";
            this.cell_2.StylePriority.UseFont = false;
            this.cell_2.StylePriority.UseForeColor = false;
            this.cell_2.StylePriority.UseTextAlignment = false;
            this.cell_2.Text = "cell_2";
            this.cell_2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_2.Weight = 0.34849333018761119D;
            // 
            // cell_3
            // 
            this.cell_3.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_3.ForeColor = System.Drawing.Color.Black;
            this.cell_3.Multiline = true;
            this.cell_3.Name = "cell_3";
            this.cell_3.StylePriority.UseFont = false;
            this.cell_3.StylePriority.UseForeColor = false;
            this.cell_3.StylePriority.UseTextAlignment = false;
            this.cell_3.Text = "cell_3";
            this.cell_3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_3.Weight = 0.34849333018761119D;
            // 
            // cell_4
            // 
            this.cell_4.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_4.ForeColor = System.Drawing.Color.Black;
            this.cell_4.Multiline = true;
            this.cell_4.Name = "cell_4";
            this.cell_4.StylePriority.UseFont = false;
            this.cell_4.StylePriority.UseForeColor = false;
            this.cell_4.StylePriority.UseTextAlignment = false;
            this.cell_4.Text = "cell_4";
            this.cell_4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_4.Weight = 0.34849333018761119D;
            // 
            // cell_5
            // 
            this.cell_5.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_5.ForeColor = System.Drawing.Color.Black;
            this.cell_5.Multiline = true;
            this.cell_5.Name = "cell_5";
            this.cell_5.StylePriority.UseFont = false;
            this.cell_5.StylePriority.UseForeColor = false;
            this.cell_5.StylePriority.UseTextAlignment = false;
            this.cell_5.Text = "cell_5";
            this.cell_5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_5.Weight = 0.34849333018761119D;
            // 
            // cell_6
            // 
            this.cell_6.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_6.ForeColor = System.Drawing.Color.Black;
            this.cell_6.Multiline = true;
            this.cell_6.Name = "cell_6";
            this.cell_6.StylePriority.UseFont = false;
            this.cell_6.StylePriority.UseForeColor = false;
            this.cell_6.StylePriority.UseTextAlignment = false;
            this.cell_6.Text = "cell_6";
            this.cell_6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_6.Weight = 0.34849333018761119D;
            // 
            // cell_7
            // 
            this.cell_7.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_7.ForeColor = System.Drawing.Color.Black;
            this.cell_7.Multiline = true;
            this.cell_7.Name = "cell_7";
            this.cell_7.StylePriority.UseFont = false;
            this.cell_7.StylePriority.UseForeColor = false;
            this.cell_7.StylePriority.UseTextAlignment = false;
            this.cell_7.Text = "cell_7";
            this.cell_7.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_7.Weight = 0.34849333018761119D;
            // 
            // cell_8
            // 
            this.cell_8.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_8.ForeColor = System.Drawing.Color.Black;
            this.cell_8.Multiline = true;
            this.cell_8.Name = "cell_8";
            this.cell_8.StylePriority.UseFont = false;
            this.cell_8.StylePriority.UseForeColor = false;
            this.cell_8.StylePriority.UseTextAlignment = false;
            this.cell_8.Text = "cell_8";
            this.cell_8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_8.Weight = 0.34849333018761119D;
            // 
            // cell_9
            // 
            this.cell_9.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_9.ForeColor = System.Drawing.Color.Black;
            this.cell_9.Multiline = true;
            this.cell_9.Name = "cell_9";
            this.cell_9.StylePriority.UseFont = false;
            this.cell_9.StylePriority.UseForeColor = false;
            this.cell_9.StylePriority.UseTextAlignment = false;
            this.cell_9.Text = "cell_9";
            this.cell_9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_9.Weight = 0.34849333018761119D;
            // 
            // cell_10
            // 
            this.cell_10.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_10.ForeColor = System.Drawing.Color.Black;
            this.cell_10.Multiline = true;
            this.cell_10.Name = "cell_10";
            this.cell_10.StylePriority.UseFont = false;
            this.cell_10.StylePriority.UseForeColor = false;
            this.cell_10.StylePriority.UseTextAlignment = false;
            this.cell_10.Text = "cell_10";
            this.cell_10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_10.Weight = 0.34849333018761119D;
            // 
            // cell_11
            // 
            this.cell_11.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_11.ForeColor = System.Drawing.Color.Black;
            this.cell_11.Multiline = true;
            this.cell_11.Name = "cell_11";
            this.cell_11.StylePriority.UseFont = false;
            this.cell_11.StylePriority.UseForeColor = false;
            this.cell_11.StylePriority.UseTextAlignment = false;
            this.cell_11.Text = "cell_11";
            this.cell_11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_11.Weight = 0.34849333018761119D;
            // 
            // cell_12
            // 
            this.cell_12.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_12.ForeColor = System.Drawing.Color.Black;
            this.cell_12.Multiline = true;
            this.cell_12.Name = "cell_12";
            this.cell_12.StylePriority.UseFont = false;
            this.cell_12.StylePriority.UseForeColor = false;
            this.cell_12.StylePriority.UseTextAlignment = false;
            this.cell_12.Text = "cell_12";
            this.cell_12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_12.Weight = 0.34849333018761119D;
            // 
            // cell_13
            // 
            this.cell_13.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_13.ForeColor = System.Drawing.Color.Black;
            this.cell_13.Multiline = true;
            this.cell_13.Name = "cell_13";
            this.cell_13.StylePriority.UseFont = false;
            this.cell_13.StylePriority.UseForeColor = false;
            this.cell_13.StylePriority.UseTextAlignment = false;
            this.cell_13.Text = "cell_13";
            this.cell_13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_13.Weight = 0.34849333018761119D;
            // 
            // cell_14
            // 
            this.cell_14.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_14.ForeColor = System.Drawing.Color.Black;
            this.cell_14.Multiline = true;
            this.cell_14.Name = "cell_14";
            this.cell_14.StylePriority.UseFont = false;
            this.cell_14.StylePriority.UseForeColor = false;
            this.cell_14.StylePriority.UseTextAlignment = false;
            this.cell_14.Text = "cell_14";
            this.cell_14.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_14.Weight = 0.34849333018761119D;
            // 
            // cell_15
            // 
            this.cell_15.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_15.ForeColor = System.Drawing.Color.Black;
            this.cell_15.Multiline = true;
            this.cell_15.Name = "cell_15";
            this.cell_15.StylePriority.UseFont = false;
            this.cell_15.StylePriority.UseForeColor = false;
            this.cell_15.StylePriority.UseTextAlignment = false;
            this.cell_15.Text = "cell_15";
            this.cell_15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_15.Weight = 0.34849333018761119D;
            // 
            // cell_16
            // 
            this.cell_16.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_16.ForeColor = System.Drawing.Color.Black;
            this.cell_16.Multiline = true;
            this.cell_16.Name = "cell_16";
            this.cell_16.StylePriority.UseFont = false;
            this.cell_16.StylePriority.UseForeColor = false;
            this.cell_16.StylePriority.UseTextAlignment = false;
            this.cell_16.Text = "cell_16";
            this.cell_16.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_16.Weight = 0.34849333018761119D;
            // 
            // cell_17
            // 
            this.cell_17.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_17.ForeColor = System.Drawing.Color.Black;
            this.cell_17.Multiline = true;
            this.cell_17.Name = "cell_17";
            this.cell_17.StylePriority.UseFont = false;
            this.cell_17.StylePriority.UseForeColor = false;
            this.cell_17.StylePriority.UseTextAlignment = false;
            this.cell_17.Text = "cell_17";
            this.cell_17.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_17.Weight = 0.34849333018761119D;
            // 
            // cell_18
            // 
            this.cell_18.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_18.ForeColor = System.Drawing.Color.Black;
            this.cell_18.Multiline = true;
            this.cell_18.Name = "cell_18";
            this.cell_18.StylePriority.UseFont = false;
            this.cell_18.StylePriority.UseForeColor = false;
            this.cell_18.StylePriority.UseTextAlignment = false;
            this.cell_18.Text = "cell_18";
            this.cell_18.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_18.Weight = 0.34849333018761119D;
            // 
            // cell_19
            // 
            this.cell_19.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_19.ForeColor = System.Drawing.Color.Black;
            this.cell_19.Multiline = true;
            this.cell_19.Name = "cell_19";
            this.cell_19.StylePriority.UseFont = false;
            this.cell_19.StylePriority.UseForeColor = false;
            this.cell_19.StylePriority.UseTextAlignment = false;
            this.cell_19.Text = "cell_19";
            this.cell_19.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_19.Weight = 0.34849333018761119D;
            // 
            // cell_20
            // 
            this.cell_20.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_20.ForeColor = System.Drawing.Color.Black;
            this.cell_20.Multiline = true;
            this.cell_20.Name = "cell_20";
            this.cell_20.StylePriority.UseFont = false;
            this.cell_20.StylePriority.UseForeColor = false;
            this.cell_20.StylePriority.UseTextAlignment = false;
            this.cell_20.Text = "cell_20";
            this.cell_20.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_20.Weight = 0.34849333018761119D;
            // 
            // cell_21
            // 
            this.cell_21.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_21.ForeColor = System.Drawing.Color.Black;
            this.cell_21.Multiline = true;
            this.cell_21.Name = "cell_21";
            this.cell_21.StylePriority.UseFont = false;
            this.cell_21.StylePriority.UseForeColor = false;
            this.cell_21.StylePriority.UseTextAlignment = false;
            this.cell_21.Text = "cell_21";
            this.cell_21.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_21.Weight = 0.34849333018761119D;
            // 
            // cell_22
            // 
            this.cell_22.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_22.ForeColor = System.Drawing.Color.Black;
            this.cell_22.Multiline = true;
            this.cell_22.Name = "cell_22";
            this.cell_22.StylePriority.UseFont = false;
            this.cell_22.StylePriority.UseForeColor = false;
            this.cell_22.StylePriority.UseTextAlignment = false;
            this.cell_22.Text = "cell_22";
            this.cell_22.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_22.Weight = 0.34849333018761119D;
            // 
            // cell_23
            // 
            this.cell_23.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_23.ForeColor = System.Drawing.Color.Black;
            this.cell_23.Multiline = true;
            this.cell_23.Name = "cell_23";
            this.cell_23.StylePriority.UseFont = false;
            this.cell_23.StylePriority.UseForeColor = false;
            this.cell_23.StylePriority.UseTextAlignment = false;
            this.cell_23.Text = "cell_23";
            this.cell_23.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_23.Weight = 0.34849333018761119D;
            // 
            // cell_24
            // 
            this.cell_24.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_24.ForeColor = System.Drawing.Color.Black;
            this.cell_24.Multiline = true;
            this.cell_24.Name = "cell_24";
            this.cell_24.StylePriority.UseFont = false;
            this.cell_24.StylePriority.UseForeColor = false;
            this.cell_24.StylePriority.UseTextAlignment = false;
            this.cell_24.Text = "cell_24";
            this.cell_24.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_24.Weight = 0.34849333018761119D;
            // 
            // cell_25
            // 
            this.cell_25.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_25.ForeColor = System.Drawing.Color.Black;
            this.cell_25.Multiline = true;
            this.cell_25.Name = "cell_25";
            this.cell_25.StylePriority.UseFont = false;
            this.cell_25.StylePriority.UseForeColor = false;
            this.cell_25.StylePriority.UseTextAlignment = false;
            this.cell_25.Text = "cell_25";
            this.cell_25.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_25.Weight = 0.34849333018761119D;
            // 
            // cell_26
            // 
            this.cell_26.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_26.ForeColor = System.Drawing.Color.Black;
            this.cell_26.Multiline = true;
            this.cell_26.Name = "cell_26";
            this.cell_26.StylePriority.UseFont = false;
            this.cell_26.StylePriority.UseForeColor = false;
            this.cell_26.StylePriority.UseTextAlignment = false;
            this.cell_26.Text = "cell_26";
            this.cell_26.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_26.Weight = 0.34849333018761119D;
            // 
            // cell_27
            // 
            this.cell_27.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_27.ForeColor = System.Drawing.Color.Black;
            this.cell_27.Multiline = true;
            this.cell_27.Name = "cell_27";
            this.cell_27.StylePriority.UseFont = false;
            this.cell_27.StylePriority.UseForeColor = false;
            this.cell_27.StylePriority.UseTextAlignment = false;
            this.cell_27.Text = "cell_27";
            this.cell_27.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_27.Weight = 0.34849333018761119D;
            // 
            // cell_28
            // 
            this.cell_28.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_28.ForeColor = System.Drawing.Color.Black;
            this.cell_28.Multiline = true;
            this.cell_28.Name = "cell_28";
            this.cell_28.StylePriority.UseFont = false;
            this.cell_28.StylePriority.UseForeColor = false;
            this.cell_28.StylePriority.UseTextAlignment = false;
            this.cell_28.Text = "cell_28";
            this.cell_28.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_28.Weight = 0.34849333018761119D;
            // 
            // cell_29
            // 
            this.cell_29.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_29.ForeColor = System.Drawing.Color.Black;
            this.cell_29.Multiline = true;
            this.cell_29.Name = "cell_29";
            this.cell_29.StylePriority.UseFont = false;
            this.cell_29.StylePriority.UseForeColor = false;
            this.cell_29.StylePriority.UseTextAlignment = false;
            this.cell_29.Text = "cell_29";
            this.cell_29.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_29.Weight = 0.34849333018761119D;
            // 
            // cell_30
            // 
            this.cell_30.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_30.ForeColor = System.Drawing.Color.Black;
            this.cell_30.Multiline = true;
            this.cell_30.Name = "cell_30";
            this.cell_30.StylePriority.UseFont = false;
            this.cell_30.StylePriority.UseForeColor = false;
            this.cell_30.StylePriority.UseTextAlignment = false;
            this.cell_30.Text = "cell_30";
            this.cell_30.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_30.Weight = 0.34849333018761119D;
            // 
            // cell_31
            // 
            this.cell_31.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.cell_31.ForeColor = System.Drawing.Color.Black;
            this.cell_31.Multiline = true;
            this.cell_31.Name = "cell_31";
            this.cell_31.StylePriority.UseFont = false;
            this.cell_31.StylePriority.UseForeColor = false;
            this.cell_31.StylePriority.UseTextAlignment = false;
            this.cell_31.Text = "cell_31";
            this.cell_31.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.cell_31.Weight = 0.34849333018761119D;
            // 
            // ReportHeader
            // 
            this.ReportHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrRichText1,
            this.xrPictureBox1,
            this.lbl_date,
            this.xrLabel7,
            this.xrLabel2});
            this.ReportHeader.HeightF = 280.5555F;
            this.ReportHeader.Name = "ReportHeader";
            // 
            // xrRichText1
            // 
            this.xrRichText1.Font = new DevExpress.Drawing.DXFont("Times New Roman", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.xrRichText1.LocationFloat = new DevExpress.Utils.PointFloat(4.137112F, 115.8334F);
            this.xrRichText1.Name = "xrRichText1";
            this.xrRichText1.SerializableRtfString = resources.GetString("xrRichText1.SerializableRtfString");
            this.xrRichText1.SizeF = new System.Drawing.SizeF(248.8636F, 100F);
            this.xrRichText1.StylePriority.UseFont = false;
            // 
            // xrPictureBox1
            // 
            this.xrPictureBox1.ImageSource = new DevExpress.XtraPrinting.Drawing.ImageSource("img", resources.GetString("xrPictureBox1.ImageSource"));
            this.xrPictureBox1.LocationFloat = new DevExpress.Utils.PointFloat(0F, 0F);
            this.xrPictureBox1.Name = "xrPictureBox1";
            this.xrPictureBox1.SizeF = new System.Drawing.SizeF(148.2707F, 107.8279F);
            this.xrPictureBox1.Sizing = DevExpress.XtraPrinting.ImageSizeMode.ZoomImage;
            // 
            // lbl_date
            // 
            this.lbl_date.Font = new DevExpress.Drawing.DXFont("Arial", 10.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.lbl_date.LocationFloat = new DevExpress.Utils.PointFloat(990.6814F, 165.75F);
            this.lbl_date.Multiline = true;
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.lbl_date.SizeF = new System.Drawing.SizeF(127.0833F, 23.00001F);
            this.lbl_date.StylePriority.UseFont = false;
            this.lbl_date.Text = "TFT LE :";
            // 
            // xrLabel7
            // 
            this.xrLabel7.Font = new DevExpress.Drawing.DXFont("Arial", 10.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.xrLabel7.LocationFloat = new DevExpress.Utils.PointFloat(911.5153F, 165.75F);
            this.xrLabel7.Multiline = true;
            this.xrLabel7.Name = "xrLabel7";
            this.xrLabel7.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel7.SizeF = new System.Drawing.SizeF(79.16666F, 23F);
            this.xrLabel7.StylePriority.UseFont = false;
            this.xrLabel7.Text = "TFT LE :";
            // 
            // xrLabel2
            // 
            this.xrLabel2.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrLabel2.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.xrLabel2.LocationFloat = new DevExpress.Utils.PointFloat(23.18878F, 225.9028F);
            this.xrLabel2.Multiline = true;
            this.xrLabel2.Name = "xrLabel2";
            this.xrLabel2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.xrLabel2.SizeF = new System.Drawing.SizeF(1107.758F, 46.66672F);
            this.xrLabel2.StylePriority.UseBorders = false;
            this.xrLabel2.StylePriority.UseFont = false;
            this.xrLabel2.StylePriority.UseTextAlignment = false;
            this.xrLabel2.Text = "Suivant Contrat de base N° I/22/TFT/2024  portant Objet \"Prestations de Gestion H" +
    "ôtelière en Full Catering des Bases de Vie Infrastructures de la Direction Régio" +
    "nale Tin Fouyé Tabankort\" ";
            this.xrLabel2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // GroupHeader1
            // 
            this.GroupHeader1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrTableHeader});
            this.GroupHeader1.HeightF = 30.90289F;
            this.GroupHeader1.Name = "GroupHeader1";
            // 
            // xrTableHeader
            // 
            this.xrTableHeader.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.xrTableHeader.BorderDashStyle = DevExpress.XtraPrinting.BorderDashStyle.Solid;
            this.xrTableHeader.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F, DevExpress.Drawing.DXFontStyle.Bold);
            this.xrTableHeader.LocationFloat = new DevExpress.Utils.PointFloat(1.009994F, 0F);
            this.xrTableHeader.Name = "xrTableHeader";
            this.xrTableHeader.Rows.AddRange(new DevExpress.XtraReports.UI.XRTableRow[] {
            this.tableRow1});
            this.xrTableHeader.SizeF = new System.Drawing.SizeF(1158.99F, 28F);
            this.xrTableHeader.StylePriority.UseBackColor = false;
            this.xrTableHeader.StylePriority.UseBorderDashStyle = false;
            this.xrTableHeader.StylePriority.UseFont = false;
            this.xrTableHeader.StylePriority.UseTextAlignment = false;
            this.xrTableHeader.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopCenter;
            // 
            // tableRow1
            // 
            this.tableRow1.Cells.AddRange(new DevExpress.XtraReports.UI.XRTableCell[] {
            this.xrTableCell1,
            this.Bloc,
            this.xrTableCell3,
            this.xrTableCell2,
            this.xrTableCell4,
            this.xrTableCell5,
            this.xrTableCell6,
            this.xrTableCell7,
            this.xrTableCell8,
            this.xrTableCell9,
            this.xrTableCell10,
            this.xrTableCell11,
            this.xrTableCell12,
            this.xrTableCell13,
            this.xrTableCell14,
            this.xrTableCell15,
            this.xrTableCell16,
            this.xrTableCell17,
            this.xrTableCell18,
            this.xrTableCell19,
            this.xrTableCell20,
            this.xrTableCell21,
            this.xrTableCell22,
            this.xrTableCell23,
            this.xrTableCell24,
            this.xrTableCell25,
            this.xrTableCell26,
            this.xrTableCell27,
            this.xrTableCell28,
            this.xrTableCell29,
            this.xrTableCell30,
            this.xrTableCell31,
            this.xrTableCell32,
            this.xrTableCell33});
            this.tableRow1.Name = "tableRow1";
            this.tableRow1.Weight = 1D;
            // 
            // xrTableCell1
            // 
            this.xrTableCell1.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell1.Multiline = true;
            this.xrTableCell1.Name = "xrTableCell1";
            this.xrTableCell1.StylePriority.UseBorders = false;
            this.xrTableCell1.StylePriority.UseTextAlignment = false;
            this.xrTableCell1.Text = "Poste";
            this.xrTableCell1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell1.Weight = 0.44417662173573319D;
            // 
            // Bloc
            // 
            this.Bloc.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.Bloc.Name = "Bloc";
            this.Bloc.StylePriority.UseBorders = false;
            this.Bloc.StylePriority.UseTextAlignment = false;
            this.Bloc.Text = "contra";
            this.Bloc.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.Bloc.Weight = 0.16156565579869753D;
            // 
            // xrTableCell3
            // 
            this.xrTableCell3.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell3.Multiline = true;
            this.xrTableCell3.Name = "xrTableCell3";
            this.xrTableCell3.StylePriority.UseBorders = false;
            this.xrTableCell3.StylePriority.UseTextAlignment = false;
            this.xrTableCell3.Text = "Nom et Prénom";
            this.xrTableCell3.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell3.Weight = 0.38046438092623003D;
            // 
            // xrTableCell2
            // 
            this.xrTableCell2.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell2.Multiline = true;
            this.xrTableCell2.Name = "xrTableCell2";
            this.xrTableCell2.StylePriority.UseBorders = false;
            this.xrTableCell2.StylePriority.UseTextAlignment = false;
            this.xrTableCell2.Text = "1";
            this.xrTableCell2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell2.Weight = 0.0956126841833127D;
            // 
            // xrTableCell4
            // 
            this.xrTableCell4.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell4.Multiline = true;
            this.xrTableCell4.Name = "xrTableCell4";
            this.xrTableCell4.StylePriority.UseBorders = false;
            this.xrTableCell4.StylePriority.UseTextAlignment = false;
            this.xrTableCell4.Text = "2";
            this.xrTableCell4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell4.Weight = 0.0956126841833127D;
            // 
            // xrTableCell5
            // 
            this.xrTableCell5.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell5.Multiline = true;
            this.xrTableCell5.Name = "xrTableCell5";
            this.xrTableCell5.StylePriority.UseBorders = false;
            this.xrTableCell5.StylePriority.UseTextAlignment = false;
            this.xrTableCell5.Text = "3";
            this.xrTableCell5.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell5.Weight = 0.0956126841833127D;
            // 
            // xrTableCell6
            // 
            this.xrTableCell6.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell6.Multiline = true;
            this.xrTableCell6.Name = "xrTableCell6";
            this.xrTableCell6.StylePriority.UseBorders = false;
            this.xrTableCell6.StylePriority.UseTextAlignment = false;
            this.xrTableCell6.Text = "4";
            this.xrTableCell6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell6.Weight = 0.0956126841833127D;
            // 
            // xrTableCell7
            // 
            this.xrTableCell7.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell7.Multiline = true;
            this.xrTableCell7.Name = "xrTableCell7";
            this.xrTableCell7.StylePriority.UseBorders = false;
            this.xrTableCell7.StylePriority.UseTextAlignment = false;
            this.xrTableCell7.Text = "5";
            this.xrTableCell7.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell7.Weight = 0.0956126841833127D;
            // 
            // xrTableCell8
            // 
            this.xrTableCell8.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell8.Multiline = true;
            this.xrTableCell8.Name = "xrTableCell8";
            this.xrTableCell8.StylePriority.UseBorders = false;
            this.xrTableCell8.StylePriority.UseTextAlignment = false;
            this.xrTableCell8.Text = "6";
            this.xrTableCell8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell8.Weight = 0.0956126841833127D;
            // 
            // xrTableCell9
            // 
            this.xrTableCell9.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell9.Multiline = true;
            this.xrTableCell9.Name = "xrTableCell9";
            this.xrTableCell9.StylePriority.UseBorders = false;
            this.xrTableCell9.StylePriority.UseTextAlignment = false;
            this.xrTableCell9.Text = "7";
            this.xrTableCell9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell9.Weight = 0.0956126841833127D;
            // 
            // xrTableCell10
            // 
            this.xrTableCell10.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell10.Multiline = true;
            this.xrTableCell10.Name = "xrTableCell10";
            this.xrTableCell10.StylePriority.UseBorders = false;
            this.xrTableCell10.StylePriority.UseTextAlignment = false;
            this.xrTableCell10.Text = "8";
            this.xrTableCell10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell10.Weight = 0.0956126841833127D;
            // 
            // xrTableCell11
            // 
            this.xrTableCell11.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell11.Multiline = true;
            this.xrTableCell11.Name = "xrTableCell11";
            this.xrTableCell11.StylePriority.UseBorders = false;
            this.xrTableCell11.StylePriority.UseTextAlignment = false;
            this.xrTableCell11.Text = "9";
            this.xrTableCell11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell11.Weight = 0.0956110802108749D;
            // 
            // xrTableCell12
            // 
            this.xrTableCell12.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell12.Multiline = true;
            this.xrTableCell12.Name = "xrTableCell12";
            this.xrTableCell12.StylePriority.UseBorders = false;
            this.xrTableCell12.StylePriority.UseTextAlignment = false;
            this.xrTableCell12.Text = "10";
            this.xrTableCell12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell12.Weight = 0.0956110802108749D;
            // 
            // xrTableCell13
            // 
            this.xrTableCell13.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell13.Multiline = true;
            this.xrTableCell13.Name = "xrTableCell13";
            this.xrTableCell13.StylePriority.UseBorders = false;
            this.xrTableCell13.StylePriority.UseTextAlignment = false;
            this.xrTableCell13.Text = "11";
            this.xrTableCell13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell13.Weight = 0.0956110802108749D;
            // 
            // xrTableCell14
            // 
            this.xrTableCell14.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell14.Multiline = true;
            this.xrTableCell14.Name = "xrTableCell14";
            this.xrTableCell14.StylePriority.UseBorders = false;
            this.xrTableCell14.StylePriority.UseTextAlignment = false;
            this.xrTableCell14.Text = "12";
            this.xrTableCell14.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell14.Weight = 0.0956110802108749D;
            // 
            // xrTableCell15
            // 
            this.xrTableCell15.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell15.Multiline = true;
            this.xrTableCell15.Name = "xrTableCell15";
            this.xrTableCell15.StylePriority.UseBorders = false;
            this.xrTableCell15.StylePriority.UseTextAlignment = false;
            this.xrTableCell15.Text = "13";
            this.xrTableCell15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell15.Weight = 0.0956110802108749D;
            // 
            // xrTableCell16
            // 
            this.xrTableCell16.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell16.Multiline = true;
            this.xrTableCell16.Name = "xrTableCell16";
            this.xrTableCell16.StylePriority.UseBorders = false;
            this.xrTableCell16.StylePriority.UseTextAlignment = false;
            this.xrTableCell16.Text = "14";
            this.xrTableCell16.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell16.Weight = 0.0956110802108749D;
            // 
            // xrTableCell17
            // 
            this.xrTableCell17.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell17.Multiline = true;
            this.xrTableCell17.Name = "xrTableCell17";
            this.xrTableCell17.StylePriority.UseBorders = false;
            this.xrTableCell17.StylePriority.UseTextAlignment = false;
            this.xrTableCell17.Text = "15";
            this.xrTableCell17.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell17.Weight = 0.0956110802108749D;
            // 
            // xrTableCell18
            // 
            this.xrTableCell18.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell18.Multiline = true;
            this.xrTableCell18.Name = "xrTableCell18";
            this.xrTableCell18.StylePriority.UseBorders = false;
            this.xrTableCell18.StylePriority.UseTextAlignment = false;
            this.xrTableCell18.Text = "16";
            this.xrTableCell18.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell18.Weight = 0.0956110802108749D;
            // 
            // xrTableCell19
            // 
            this.xrTableCell19.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell19.Multiline = true;
            this.xrTableCell19.Name = "xrTableCell19";
            this.xrTableCell19.StylePriority.UseBorders = false;
            this.xrTableCell19.StylePriority.UseTextAlignment = false;
            this.xrTableCell19.Text = "17";
            this.xrTableCell19.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell19.Weight = 0.0956110802108749D;
            // 
            // xrTableCell20
            // 
            this.xrTableCell20.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell20.Multiline = true;
            this.xrTableCell20.Name = "xrTableCell20";
            this.xrTableCell20.StylePriority.UseBorders = false;
            this.xrTableCell20.StylePriority.UseTextAlignment = false;
            this.xrTableCell20.Text = "18";
            this.xrTableCell20.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell20.Weight = 0.0956110802108749D;
            // 
            // xrTableCell21
            // 
            this.xrTableCell21.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell21.Multiline = true;
            this.xrTableCell21.Name = "xrTableCell21";
            this.xrTableCell21.StylePriority.UseBorders = false;
            this.xrTableCell21.StylePriority.UseTextAlignment = false;
            this.xrTableCell21.Text = "19";
            this.xrTableCell21.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell21.Weight = 0.0956110802108749D;
            // 
            // xrTableCell22
            // 
            this.xrTableCell22.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell22.Multiline = true;
            this.xrTableCell22.Name = "xrTableCell22";
            this.xrTableCell22.StylePriority.UseBorders = false;
            this.xrTableCell22.StylePriority.UseTextAlignment = false;
            this.xrTableCell22.Text = "20";
            this.xrTableCell22.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell22.Weight = 0.0956110802108749D;
            // 
            // xrTableCell23
            // 
            this.xrTableCell23.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell23.Multiline = true;
            this.xrTableCell23.Name = "xrTableCell23";
            this.xrTableCell23.StylePriority.UseBorders = false;
            this.xrTableCell23.StylePriority.UseTextAlignment = false;
            this.xrTableCell23.Text = "21";
            this.xrTableCell23.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell23.Weight = 0.0956110802108749D;
            // 
            // xrTableCell24
            // 
            this.xrTableCell24.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell24.Multiline = true;
            this.xrTableCell24.Name = "xrTableCell24";
            this.xrTableCell24.StylePriority.UseBorders = false;
            this.xrTableCell24.StylePriority.UseTextAlignment = false;
            this.xrTableCell24.Text = "22";
            this.xrTableCell24.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell24.Weight = 0.0956110802108749D;
            // 
            // xrTableCell25
            // 
            this.xrTableCell25.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell25.Multiline = true;
            this.xrTableCell25.Name = "xrTableCell25";
            this.xrTableCell25.StylePriority.UseBorders = false;
            this.xrTableCell25.StylePriority.UseTextAlignment = false;
            this.xrTableCell25.Text = "23";
            this.xrTableCell25.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell25.Weight = 0.0956110802108749D;
            // 
            // xrTableCell26
            // 
            this.xrTableCell26.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell26.Multiline = true;
            this.xrTableCell26.Name = "xrTableCell26";
            this.xrTableCell26.StylePriority.UseBorders = false;
            this.xrTableCell26.StylePriority.UseTextAlignment = false;
            this.xrTableCell26.Text = "24";
            this.xrTableCell26.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell26.Weight = 0.0956110802108749D;
            // 
            // xrTableCell27
            // 
            this.xrTableCell27.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell27.Multiline = true;
            this.xrTableCell27.Name = "xrTableCell27";
            this.xrTableCell27.StylePriority.UseBorders = false;
            this.xrTableCell27.StylePriority.UseTextAlignment = false;
            this.xrTableCell27.Text = "25";
            this.xrTableCell27.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell27.Weight = 0.0956110802108749D;
            // 
            // xrTableCell28
            // 
            this.xrTableCell28.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell28.Multiline = true;
            this.xrTableCell28.Name = "xrTableCell28";
            this.xrTableCell28.StylePriority.UseBorders = false;
            this.xrTableCell28.StylePriority.UseTextAlignment = false;
            this.xrTableCell28.Text = "26";
            this.xrTableCell28.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell28.Weight = 0.0956110802108749D;
            // 
            // xrTableCell29
            // 
            this.xrTableCell29.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell29.Multiline = true;
            this.xrTableCell29.Name = "xrTableCell29";
            this.xrTableCell29.StylePriority.UseBorders = false;
            this.xrTableCell29.StylePriority.UseTextAlignment = false;
            this.xrTableCell29.Text = "27";
            this.xrTableCell29.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell29.Weight = 0.0956110802108749D;
            // 
            // xrTableCell30
            // 
            this.xrTableCell30.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell30.Multiline = true;
            this.xrTableCell30.Name = "xrTableCell30";
            this.xrTableCell30.StylePriority.UseBorders = false;
            this.xrTableCell30.StylePriority.UseTextAlignment = false;
            this.xrTableCell30.Text = "28";
            this.xrTableCell30.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell30.Weight = 0.0956110802108749D;
            // 
            // xrTableCell31
            // 
            this.xrTableCell31.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell31.Multiline = true;
            this.xrTableCell31.Name = "xrTableCell31";
            this.xrTableCell31.StylePriority.UseBorders = false;
            this.xrTableCell31.StylePriority.UseTextAlignment = false;
            this.xrTableCell31.Text = "29";
            this.xrTableCell31.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell31.Weight = 0.0956110802108749D;
            // 
            // xrTableCell32
            // 
            this.xrTableCell32.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell32.Multiline = true;
            this.xrTableCell32.Name = "xrTableCell32";
            this.xrTableCell32.StylePriority.UseBorders = false;
            this.xrTableCell32.StylePriority.UseTextAlignment = false;
            this.xrTableCell32.Text = "30";
            this.xrTableCell32.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell32.Weight = 0.0956110802108749D;
            // 
            // xrTableCell33
            // 
            this.xrTableCell33.Borders = DevExpress.XtraPrinting.BorderSide.None;
            this.xrTableCell33.Multiline = true;
            this.xrTableCell33.Name = "xrTableCell33";
            this.xrTableCell33.StylePriority.UseBorders = false;
            this.xrTableCell33.StylePriority.UseTextAlignment = false;
            this.xrTableCell33.Text = "31";
            this.xrTableCell33.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            this.xrTableCell33.Weight = 0.0956110802108749D;
            // 
            // GroupFooter1
            // 
            this.GroupFooter1.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.xrLabel1});
            this.GroupFooter1.Name = "GroupFooter1";
            // 
            // xrLabel1
            // 
            this.xrLabel1.LocationFloat = new DevExpress.Utils.PointFloat(902.3685F, 10.00001F);
            this.xrLabel1.Name = "xrLabel1";
            this.xrLabel1.SizeF = new System.Drawing.SizeF(200F, 29.16667F);
            this.xrLabel1.Text = "RESPONSABLE MCA / RNS ";
            // 
            // rpt_pointage
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.TopMargin,
            this.BottomMargin,
            this.Detail,
            this.ReportHeader,
            this.GroupHeader1,
            this.GroupFooter1});
            this.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F);
            this.Landscape = true;
            this.Margins = new DevExpress.Drawing.DXMargins(3F, 5F, 12.5F, 100F);
            this.PageHeight = 827;
            this.PageWidth = 1169;
            this.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.Version = "22.2";
            ((System.ComponentModel.ISupportInitialize)(this.xrTableDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrRichText1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrTableHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.TopMarginBand TopMargin;
        private DevExpress.XtraReports.UI.BottomMarginBand BottomMargin;
        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        private DevExpress.XtraReports.UI.GroupHeaderBand GroupHeader1;
        private DevExpress.XtraReports.UI.GroupFooterBand GroupFooter1;
        private DevExpress.XtraReports.UI.XRTable xrTableDetail;
        private DevExpress.XtraReports.UI.XRTableRow xrTableRow2;
        private DevExpress.XtraReports.UI.XRTableCell cell_sp;
        private DevExpress.XtraReports.UI.XRTableCell cell_required;
        private DevExpress.XtraReports.UI.XRTableCell cell_name;
        private DevExpress.XtraReports.UI.XRTableCell cell_1;
        private DevExpress.XtraReports.UI.XRTableCell cell_2;
        private DevExpress.XtraReports.UI.XRTableCell cell_3;
        private DevExpress.XtraReports.UI.XRTableCell cell_4;
        private DevExpress.XtraReports.UI.XRTableCell cell_5;
        private DevExpress.XtraReports.UI.XRTableCell cell_6;
        private DevExpress.XtraReports.UI.XRTableCell cell_7;
        private DevExpress.XtraReports.UI.XRTableCell cell_8;
        private DevExpress.XtraReports.UI.XRTableCell cell_9;
        private DevExpress.XtraReports.UI.XRTableCell cell_10;
        private DevExpress.XtraReports.UI.XRTableCell cell_11;
        private DevExpress.XtraReports.UI.XRTableCell cell_12;
        private DevExpress.XtraReports.UI.XRTableCell cell_13;
        private DevExpress.XtraReports.UI.XRTableCell cell_14;
        private DevExpress.XtraReports.UI.XRTableCell cell_15;
        private DevExpress.XtraReports.UI.XRTableCell cell_16;
        private DevExpress.XtraReports.UI.XRTableCell cell_17;
        private DevExpress.XtraReports.UI.XRTableCell cell_18;
        private DevExpress.XtraReports.UI.XRTableCell cell_19;
        private DevExpress.XtraReports.UI.XRTableCell cell_20;
        private DevExpress.XtraReports.UI.XRTableCell cell_21;
        private DevExpress.XtraReports.UI.XRTableCell cell_22;
        private DevExpress.XtraReports.UI.XRTableCell cell_23;
        private DevExpress.XtraReports.UI.XRTableCell cell_24;
        private DevExpress.XtraReports.UI.XRTableCell cell_25;
        private DevExpress.XtraReports.UI.XRTableCell cell_26;
        private DevExpress.XtraReports.UI.XRTableCell cell_27;
        private DevExpress.XtraReports.UI.XRTableCell cell_28;
        private DevExpress.XtraReports.UI.XRTableCell cell_29;
        private DevExpress.XtraReports.UI.XRTableCell cell_30;
        private DevExpress.XtraReports.UI.XRTableCell cell_31;
        private DevExpress.XtraReports.UI.XRRichText xrRichText1;
        private DevExpress.XtraReports.UI.XRPictureBox xrPictureBox1;
        private DevExpress.XtraReports.UI.XRLabel lbl_date;
        private DevExpress.XtraReports.UI.XRLabel xrLabel7;
        private DevExpress.XtraReports.UI.XRLabel xrLabel2;
        private DevExpress.XtraReports.UI.XRTable xrTableHeader;
        private DevExpress.XtraReports.UI.XRTableRow tableRow1;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell1;
        private DevExpress.XtraReports.UI.XRTableCell Bloc;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell3;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell2;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell4;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell5;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell6;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell7;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell8;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell9;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell10;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell11;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell12;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell13;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell14;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell15;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell16;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell17;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell18;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell19;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell20;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell21;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell22;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell23;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell24;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell25;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell26;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell27;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell28;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell29;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell30;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell31;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell32;
        private DevExpress.XtraReports.UI.XRTableCell xrTableCell33;
        private DevExpress.XtraReports.UI.XRLabel xrLabel1;
    }
}
